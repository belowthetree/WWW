<?php

function fun(){
    echo "fun";
}
echo "aaa";
?>