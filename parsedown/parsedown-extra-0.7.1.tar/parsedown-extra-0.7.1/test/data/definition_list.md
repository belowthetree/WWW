Term 1
:   one
:   two
    extra line

Term 2

:   lazy
line

:   multiple

    paragraphs

:   nested

        code block

    > quote
    > block